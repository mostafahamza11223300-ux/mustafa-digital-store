<!DOCTYPE html>  
<html lang="ar" dir="rtl">  
<head>  
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">  
    <title>تطبيق متجري</title>  
      
    <!-- للـ PWA -->  
    <link rel="manifest" href="/manifest.json">  
    <meta name="theme-color" content="#1e3c72">  
    <meta name="apple-mobile-web-app-capable" content="yes">  
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">  
      
    <!-- الخطوط والأيقونات -->  
    <link rel="preconnect" href="https://fonts.googleapis.com">  
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>  
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;900&display=swap" rel="stylesheet">  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">  
      
    <style>  
        * {  
            margin: 0;  
            padding: 0;  
            box-sizing: border-box;  
            font-family: 'Tajawal', sans-serif;  
        }  
  
        body {  
            background-color: #f4f7fc;  
            direction: rtl;  
        }  
  
        /* شريط التطبيق العلوي */  
        .app-bar {  
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);  
            color: white;  
            padding: 1.2rem 1rem;  
            display: flex;  
            justify-content: space-between;  
            align-items: center;  
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);  
            position: sticky;  
            top: 0;  
            z-index: 1000;  
        }  
  
        .app-title {  
            font-size: 1.5rem;  
            font-weight: 900;  
        }  
  
        .app-title span {  
            color: #ffc107;  
        }  
  
        .cart-badge {  
            position: relative;  
            font-size: 1.5rem;  
        }  
  
        .cart-count {  
            position: absolute;  
            top: -10px;  
            right: -10px;  
            background-color: #ff4444;  
            color: white;  
            border-radius: 50%;  
            padding: 0.2rem 0.5rem;  
            font-size: 0.8rem;  
            font-weight: bold;  
            border: 2px solid white;  
        }  
  
        /* التبويبات السفلية (زي التطبيقات) */  
        .bottom-tabs {  
            position: fixed;  
            bottom: 0;  
            width: 100%;  
            background: white;  
            display: flex;  
            justify-content: space-around;  
            padding: 0.8rem 0;  
            box-shadow: 0 -2px 20px rgba(0,0,0,0.1);  
            z-index: 1000;  
            border-top-right-radius: 25px;  
            border-top-left-radius: 25px;  
        }  
  
        .tab-item {  
            text-align: center;  
            color: #777;  
            font-size: 0.8rem;  
            transition: all 0.3s;  
            flex: 1;  
        }  
  
        .tab-item i {  
            font-size: 1.5rem;  
            display: block;  
            margin-bottom: 0.2rem;  
        }  
  
        .tab-item.active {  
            color: #1e3c72;  
            font-weight: bold;  
        }  
  
        /* المحتوى الرئيسي */  
        .main-content {  
            padding: 1rem 1rem 80px 1rem;  
            min-height: 100vh;  
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);  
        }  
  
        /* بطاقة المنتج */  
        .product-grid {  
            display: grid;  
            grid-template-columns: repeat(2, 1fr);  
            gap: 1rem;  
        }  
  
        .product-card {  
            background: white;  
            border-radius: 20px;  
            overflow: hidden;  
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);  
            transition: transform 0.3s;  
            animation: fadeIn 0.5s ease;  
        }  
  
        @keyframes fadeIn {  
            from { opacity: 0; transform: translateY(20px); }  
            to { opacity: 1; transform: translateY(0); }  
        }  
  
        .product-image {  
            height: 150px;  
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);  
            display: flex;  
            align-items: center;  
            justify-content: center;  
            color: white;  
            font-size: 3rem;  
        }  
  
        .product-info {  
            padding: 1rem;  
        }  
  
        .product-title {  
            font-size: 1rem;  
            font-weight: 700;  
            color: #333;  
            margin-bottom: 0.3rem;  
        }  
  
        .product-price {  
            font-size: 1.2rem;  
            font-weight: 900;  
            color: #28a745;  
            margin-bottom: 0.8rem;  
        }  
  
        .add-btn {  
            background: #1e3c72;  
            color: white;  
            border: none;  
            padding: 0.6rem;  
            border-radius: 12px;  
            width: 100%;  
            font-weight: 600;  
            font-size: 0.9rem;  
            display: flex;  
            align-items: center;  
            justify-content: center;  
            gap: 0.5rem;  
            transition: all 0.3s;  
        }  
  
        .add-btn:active {  
            transform: scale(0.95);  
            background: #ffc107;  
            color: #1e3c72;  
        }  
  
        /* شاشة السلة */  
        .cart-screen {  
            display: none;  
            animation: slideUp 0.3s ease;  
        }  
  
        @keyframes slideUp {  
            from { transform: translateY(100%); }  
            to { transform: translateY(0); }  
        }  
  
        .cart-item {  
            background: white;  
            padding: 1rem;  
            border-radius: 15px;  
            margin-bottom: 1rem;  
            display: flex;  
            justify-content: space-between;  
            align-items: center;  
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);  
        }  
  
        .cart-item-info h4 {  
            font-size: 1rem;  
            color: #333;  
        }  
  
        .cart-item-price {  
            color: #28a745;  
            font-weight: bold;  
        }  
  
        .remove-item {  
            color: #ff4444;  
            font-size: 1.2rem;  
            cursor: pointer;  
            padding: 0.5rem;  
        }  
  
        .checkout-btn {  
            background: linear-gradient(135deg, #1e3c72, #2a5298);  
            color: white;  
            border: none;  
            padding: 1rem;  
            border-radius: 15px;  
            width: 100%;  
            font-size: 1.2rem;  
            font-weight: bold;  
            margin-top: 1rem;  
            box-shadow: 0 4px 15px rgba(30, 60, 114, 0.3);  
        }  
  
        .empty-cart {  
            text-align: center;  
            padding: 3rem;  
            color: #777;  
            font-size: 1.2rem;  
        }  
  
        /* شاشة الملف الشخصي */  
        .profile-screen {  
            display: none;  
            text-align: center;  
            padding: 2rem 1rem;  
            animation: fadeIn 0.5s;  
        }  
  
        .profile-avatar {  
            font-size: 5rem;  
            color: #1e3c72;  
            margin-bottom: 1rem;  
        }  
  
        .profile-name {  
            font-size: 1.5rem;  
            font-weight: bold;  
            color: #333;  
        }  
  
        .profile-email {  
            color: #666;  
            margin-bottom: 2rem;  
        }  
  
        .profile-menu-item {  
            background: white;  
            padding: 1rem;  
            border-radius: 15px;  
            margin-bottom: 0.5rem;  
            text-align: right;  
            display: flex;  
            align-items: center;  
            gap: 1rem;  
            color: #333;  
            font-weight: 500;  
        }  
  
        .profile-menu-item i {  
            color: #1e3c72;  
            width: 25px;  
        }  
  
        /* زرار تثبيت التطبيق */  
        .install-btn {  
            background: #ffc107;  
            color: #1e3c72;  
            border: none;  
            padding: 0.8rem;  
            border-radius: 10px;  
            width: 100%;  
            font-weight: bold;  
            margin-bottom: 1rem;  
            display: flex;  
            align-items: center;  
            justify-content: center;  
            gap: 0.5rem;  
            animation: pulse 2s infinite;  
